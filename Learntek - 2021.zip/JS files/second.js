document.write("<h1>Second JS file.....loaded</h1>");
document.write("<p>this is the paragraph</p>")
document.write("<h1>Second JS file.....loaded</h1><p>this is the paragraph</p>");
document.write(new Date());//Date is a predefined class 
var PI;

function check1(){
    var name= "1234";//string
    var value = 1234;//integer
    if(name === value){
        alert("true");
    }
    else {
        alert("false"); 
    }
}