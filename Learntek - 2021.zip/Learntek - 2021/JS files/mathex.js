
function show() {


    document.write(Math.sin(0));

}