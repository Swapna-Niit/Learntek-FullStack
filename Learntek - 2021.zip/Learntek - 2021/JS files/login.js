function validateUser() {

    var username = document.getElementById("uname").value;
    var password = document.getElementById("password").value;
    //RegEx RegularExpression is a sequence of character that forms a pattern which is used for 
    //searching the text and validating the text
    
    var emailpattern = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
    var pwdpattern= /^[A-Za-z]{6,14}$/;
    var mobileno = /^[0-9]{10}$/;
    if((username == '')|| (!emailpattern.test(username)))
    {
        alert("check your username");
        return false;
    }
    else if((password == '')|| (!pwdpattern.test(password)))
    {
        alert("check password");
        return false;
    }

    alert("login form submitted.....");
    alert("Welcome " + username + "  " + password);
}

function clearForm() {
   document.getElementById("uname").value = "";
    document.getElementById("password").value = "";
}

var hobbies = ["Playing Cricket","Reading Books","Gardening"];

var roles = [];

function displayHobbies() {
    var data = "";
    for(i=0 ; i < hobbies.length ;i++) {
       data += hobbies[i] + "<br>"; 
    }
    console.log(data);
    document.getElementById("hobbiesList").innerHTML = data;
}
//js object
var student = {
    stdId : 123,
    stdName : "Rama",
    stdAge : 25,
    stdPercentage : 65.78
};

function displayStudentDetails() {
    var stdData = "";
    var std;
    for(std in student){
        stdData += student[std]+ "<br>";
    }
    console.log(stdData);
    document.getElementById("stdDetails").innerHTML = stdData;
}
function skills() {
    skillSet = ["C","C++","Java","JavaScript","Python","Oracle"];
    skillSet.forEach(displaySkills);//a call back function
}
var output = "";
function displaySkills(value,index,array) {
    output = output + value + "<br>";
    console.log(output);
    document.getElementById("skillset").innerHTML = output;
}

function printSkil() {
    var skillValue =  document.getElementById("skillSet").value;
    document.getElementById("dropdownvalue").innerHTML = " You have selected " + skillValue;
}