var today,doj,text;
today = new Date();
doj = new Date(2017,5,14);
function compareDates(){

    if((today-doj) > 3){
        console.log("experience is greater than 3 years");
    }else{
        console.log("experience is not greater than 3 years");
    }

}