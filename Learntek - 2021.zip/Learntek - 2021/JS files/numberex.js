
function show() {

    //var res = Number.isFinite(123456) + ": 123456 <br>";
    var value = 4.56789;
    var res =value.toExponential();
    document.getElementById("result").innerHTML = res;

}