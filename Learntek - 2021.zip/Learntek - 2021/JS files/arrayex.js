//Array Creating
var flowers = ['jasmine','Rose','Marigold'];
function arrayExample() {
var flowers = ['jasmine','Rose','Marigold','Lavender'];

flowers.push("lilly");
flowers.unshift("Red Roses");
//flowers.shift();
document.getElementById("original").innerHTML = flowers;

var stationary = ['pen',
'pencil',
'Eraser'];
stationary.shift();

//new 
var vehicle = new Array("Car","Bus","Flight");
vehicle.pop();

//empty array
var gender = [];
gender[0] = "male";
gender[1] = "female";

//document.getElementById("result").innerHTML = stationary ;
//output function to write on the browser
/* document.write(flowers.concat(vehicle)+"<br>");
document.write(stationary.join(" or ")+"<br>");
document.write(gender.join()+"<br>");
document.write(flowers.sort()+"<br>");
document.write(flowers.reverse()+"<br>");
document.write(flowers.slice(1,4)+"<br>"); */
document.write(flowers.splice(2,0,"white roses"));
//+ "<br>" + stationary +"<br>" +vehicle+"<br>"+gender
}
//empty array
var gender = [];
gender[0] = "male";
gender[1] = "female";
function checkGender(gender){
    if(gender === "female") {
        return true;
    }
}

function passGender() {
    document.getElementById("result").innerHTML = gender.find(checkGender);
}

var numbers = [2,3,4,5,6,7,8,9,10,11,12];

function checkEven(numbers) {
    if((numbers%2) == 0){
        return true;
    }
}

function evenNumbers() {
    document.getElementById("result").innerHTML = numbers.find(checkEven);
}