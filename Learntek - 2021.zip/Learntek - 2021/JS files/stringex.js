var quote = "Friend in need is a friend in deed";
var quote1 = "Best Friend is equivalent to 100 books";
var word = "      SenSation     "
var numbers = [23,24,25];

document.getElementById("original").innerHTML = word.length;

function stringMethods() {

    //document.getElementById("result").innerHTML = quote.charAt(5);

    document.getElementById("result").innerHTML = word.trim().length;

}

function convertarrtostr() {
    document.getElementById("arrstr").innerHTML = numbers.toString().charAt(0);
}

var words = [];
function splitIntoWords() {
 words = quote.split(" ");
 document.write(words);
}

function sliceString() {
    var word = quote1.slice(0,11);
    document.write(word);
}