var bookType = ['fiction','story','thriller','politics'];
document.getElementById("original").innerHTML = bookType;

function addBookType() {
    bookType.splice(2,2,"horror","devotional");
    document.getElementById("result").innerHTML = bookType;
}