console.log("this is the output from check() function");
 var value1 = 350,value2 = 450;
var valname = "Krishna";//string literal
var salary = 23456.789;//float literal 
valname = 6789;
function check(){
    console.log(value1);    
    //reads the value entered inside the input tag with id "phoneno"
    var value = document.getElementById("phoneno").value;//IN
    alert(Number(value)+300);
  if(confirm("do you want to save data")== true) {
        result = "data saved successfully";
    }
    else{
        result = "data not saved successfully";
    }
    //innerHTML is the property which sets the HTML content of an element
    document.getElementById("saved").innerHTML = result//OUT

//prompt box example
var age = prompt("enter the age in years","18");
var variable2;
if (age >= 18){
    variable2 = 1000;
    let variable1 = 650; //scope of the value is inside the block
    console.log(variable1);
        result = "valid age";
    }
else{
    result = "not a valid age";
    variable2 = 1300;
    console.log(variable2);
    console.log(variable1);
}
document.getElementById("saved1").innerHTML = result//OUT
}
